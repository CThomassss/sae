<?php
// Informations de connexion à la base de données
$host = 'votre_hôte'; // généralement 'localhost'
$port = 'votre_port'; // par défaut, il s'agit du port 5432 pour PostgreSQL
$database = 'votre_base_de_données';
$user = 'votre_utilisateur';
$password = 'votre_mot_de_passe';

// Connexion à la base de données
$conn = pg_connect("host=$host port=$port dbname=$database user=$user password=$password");

// Vérifier la connexion
if (!$conn) {
    die("Échec de la connexion à la base de données : " . pg_last_error());
}

// Définir le jeu de caractères à utf8
pg_set_client_encoding($conn, "utf8");
?>