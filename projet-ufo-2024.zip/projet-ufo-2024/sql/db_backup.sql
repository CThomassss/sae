CREATE TABLE IF NOT EXISTS manifestation (
    id SERIAL PRIMARY KEY,
    date_evenement DATE NOT NULL,
    lieu VARCHAR(255) NOT NULL,
    temoin TEXT NOT NULL,
    description TEXT NOT NULL
);

INSERT INTO manifestation (date_evenement, lieu, temoin, description) VALUES
    ('2024-03-01', 'Toulouse', 'Ombre', 'Observation étrange dans le ciel.'),
    ('2024-02-28', 'Montpellier', 'La Vagabonde Céleste', 'Lumière non identifiée près de la plage.'),
    ('2024-02-25', 'Carcassonne', 'Enigma', 'Objet volant non identifié au-dessus de la cité.'),
    ('2024-02-22', 'Perpignan', 'Silence', 'Phénomène céleste mystérieux.'),
    ('2024-02-20', 'Nîmes', 'Oiseau de Nuit', 'Observation nocturne dans la campagne.'),
    ('2024-02-18', 'Albi', 'Invisible', 'Événement étrange dans le ciel.'),
    ('2024-02-15', 'Béziers', 'Silence', 'Lumière clignotante au-dessus de la ville.'),
    ('2024-02-12', 'Foix', 'Astrale', 'Observation céleste fascinante.'),
    ('2024-02-10', 'Limoux', 'La Vagabonde Céleste', 'Objet volant non identifié près du lac.'),
    ('2024-02-08', 'Mende', 'La Vagabonde Céleste', 'Phénomène mystérieux dans le ciel.');

