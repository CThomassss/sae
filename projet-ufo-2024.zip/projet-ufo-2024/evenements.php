<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css"> <!-- Assurez-vous que le chemin vers votre fichier CSS est correct -->
    <title>Événements Recensés</title>
</head>
<body>
    <div class="container">
        <div class="section">
            <h2>Événements Recensés</h2>
            <p>Explorez les manifestations d'OVNIs en Occitanie.</p>

            <?php
            // Inclure la connexion à la base de données
            include('includes/connexion_bd.php');

            // Sélectionner les manifestations
            $sql = "SELECT * FROM manifestation ORDER BY date_evenement DESC";
            $result = pg_query($conn, $sql);

            if ($result && pg_num_rows($result) > 0) {
                while ($row = pg_fetch_assoc($result)) {
                    echo '<div class="manifestation-item">';
                    echo '<h3>' . $row['date_evenement'] . ' - ' . $row['lieu'] . '</h3>';
                    echo '<p><strong>Témoin :</strong> ' . $row['temoin'] . '</p>';
                    echo '<p><strong>Description :</strong> ' . $row['description'] . '</p>';
                    echo '</div>';
                }
            } else {
                echo '<p>Aucune manifestation recensée pour le moment.</p>';
            }

            // Fermer la connexion à la base de données
            pg_close($conn);
            ?>
        </div>
    </div>

    <div class="footer">
        <p>&copy; 2024 Association d'Observation d'OVNIs en Occitanie</p>
    </div>
</body>
</html>

